from tkinter import *
from PIL import Image, ImageTk
import webbrowser
import os
import wikipedia

root = Tk()

bgc = "black"
fgc = "white"

root.config(bg=bgc)

root.minsize(1000, 800)
root.maxsize(1000, 800)

root.title("DARSHAN'S TECHNOLOGIES-(D-TECH)")


def instagram():
    webbrowser.open("www.instagram.com")


def facebook():
    webbrowser.open("www.facebook.com")


def youtube():
    webbrowser.open("www.youtube.com")


def whatsapp():
    webbrowser.open("https://web.whatsapp.com/")


def meet():
    webbrowser.open("https://meet.google.com/")


def cmd():
    os.startfile("C:\\Windows\\System32\\cmd.exe")


def notepad():
    os.startfile("C:\\Windows\\notepad.exe")


def powershell():
    os.startfile("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe")


def file():
    os.startfile("C:\\Windows\\explorer.exe")


def wiki_call():
    wiki = Tk()
    wiki.minsize(1000, 500)
    wiki.maxsize(1000, 550)
    import wikipedia
    wiki.title("Darshan's Technologies")
    wiki.config(bg="navy")
    bgcol = "navy"
    Label(wiki, text="Darshan's Technologies(D.TECH)", font=("Stencil 30 bold underline"), bg=bgcol, fg="white").pack()
    Label(wiki, text="IMAGINAITON ENDS IMPLEMENTATION BEGINS", font=("Stencil 15 bold underline"), bg=bgcol,
          fg="white").pack()
    t = Text(wiki,width=190, height=20, bg=bgcol, fg="white")
    t.pack()
    usr = StringVar()
    l = Label(wiki, text="Keyword: ", bg=bgcol, fg="red", font="Times 10")
    l.place(x=341, y=410)
    e = Entry(wiki,textvariable=usr, bg=bgcol, fg="white")
    e.pack()
    l1 = Label(wiki,text="No. of lines: ", bg=bgcol, fg="red", font="Times 10")
    l1.place(x=330, y=425)
    i = IntVar()
    i_ = Entry(wiki,textvariable=i, bg=bgcol, fg="white")
    i_.pack()

    def click(event):
        r = wikipedia.summary(f"{usr.get()}", f"{i.get()}")
        t.insert(1.0, r)

    def reset(event):
        t.delete("1.0", "end")

    b1 = Button(wiki,text="search", bg=bgcol, fg="white", bd=5, command=click)
    b1.bind("<Return>", click)
    b1.pack()
    b2 = Button(wiki,text="reset", bg=bgcol, fg="white", bd=5, command=reset)
    b2.bind("<Return>", reset)
    b2.pack()
    b3 = Button(wiki,text="end", bg=bgcol, fg="white", bd=5, command=root.destroy)
    b3.pack()
    root.mainloop()


img = Image.open("home_a.png")
img_resize = img.resize((50, 50))

photo = ImageTk.PhotoImage(img_resize)

search = Image.open("home_b.png")
search_resize = search.resize((50, 50))

search_photo = ImageTk.PhotoImage(search_resize)

menu = Image.open("menu.png")
menu_resize = menu.resize((50, 50))

menu_photo = ImageTk.PhotoImage(menu_resize)

title = Frame(root, width=1000, bd=10, bg=bgc)
title.pack()

def dtech():
    webbrowser.open("https://sketch0.github.io/MarketPlace/")

Button(title, text="DARSHAN'S TECHNOLOGIES-(D-TECH)", font=("Stencil 30 bold underline"), bg=bgc, fg=fgc , command=dtech).pack()
Label(title, text="IMAGINATION ENDS AND IMPLEMENTATION BEGINS",font=("Times 20 underline italic"),bg=bgc,fg=fgc).pack()

sec_title = Frame(title, width=900, bd=8, bg=bgc)
sec_title.pack()

a = Button(sec_title, image=photo, bg=bgc, fg=fgc, cursor="target")
# a.grid(row=0, column=0)
a.pack(side="left")

def google():
    webbrowser.open("www.google.com")

b = Button(sec_title, image=search_photo, bg=bgc, fg=fgc, command=google, cursor="target")
# b.grid(row=0, column=8, padx=400)
b.pack(side="right")

c = Button(sec_title, image=menu_photo, bg=bgc, fg=fgc, cursor="target")
# c.grid(row=0, column=10)
c.pack(side="right")

menu = Frame(root, bg="gray", bd=10, width=900, height=650, cursor="target")
menu.pack()

frame_1 = Frame(menu, bd=20, width=600, height=300, bg=bgc)
frame_1.pack()

frame = Frame(menu, bd=20, width=600, height=300, bg=bgc)
frame.pack()

Label(frame_1, text="MANY PROBLEMS ONE SOLUTION , ONE WINDOW", font=("Times 9"), bg=bgc, fg=fgc).grid()

Button(frame, text="Instagram", bd=4, command=instagram, bg=bgc, fg=fgc).grid(row=4, column=0)
Button(frame, text="Facebook", bd=4, command=facebook, bg=bgc, fg=fgc).grid(row=4, column=2)
Button(frame, text="Youtube", bd=4, command=youtube, bg=bgc, fg=fgc).grid(row=8, column=0)
Button(frame, text="Whatsapp", bd=4, command=whatsapp, bg=bgc, fg=fgc).grid(row=8, column=2)

Button(frame, text="Notepad", bd=4, command=notepad, fg=fgc, bg=bgc).grid(row=12, column=0)
Button(frame, text="Cmd", bd=4, command=cmd, bg=bgc, fg=fgc).grid(row=12, column=2)
Button(frame, text="Powershell", bd=4, command=powershell, fg=fgc, bg=bgc).grid(row=0, column=0)
Button(frame, text="FileManager", bd=4, command=file, fg=fgc, bg=bgc).grid(row=0, column=2)

Button(frame, text="Meet", bd=4, command=meet, bg=bgc, fg=fgc).grid(row=16, column=0)
Button(frame, text="End", bd=4, command=root.destroy, fg=fgc, bg=bgc).grid(row=16, column=2)

text_frame = Frame(root, width=200, height=100, bd=5, bg=bgc)
text_frame.pack()

Label(text_frame,
      text="This is a normal application or normal GUI interface where you can access different different features \n of your system from only one window without searching any where else\n.",
      font=("Times 15 italic"), bg=bgc, fg=fgc).pack()
Label(text_frame, text="THANK YOU", font=("Stencil 14 italic underline"), bg=bgc, fg=fgc).pack()
Label(text_frame, text="founder and CEO of D-TECH", font=("Times 10 underline"), bg=bgc, fg="gray").pack(side="right")
Label(text_frame, text="By Darshan Sahoo", font=("Script 20 underline italic"), bg=bgc, fg=fgc).pack(side="right")

root.mainloop()
